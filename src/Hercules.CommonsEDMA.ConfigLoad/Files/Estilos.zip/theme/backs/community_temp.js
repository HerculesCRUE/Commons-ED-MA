$(document).ready(function () {	
	comportamientoCV.init();
});
var urlEdicion="http://serviciosedma.gnoss.com/guardadocv/EdicionDocumentos/";


var comportamientoCV = {
    init: function () {
        this.config();
    },
    config: function () {
		that=this;
		$('body').append('<input title="Fecha de la publicación"  value="" type="text" class="ac_input datepicker form-control not-outline" placeholder="Introduce la fecha de publicación" name="" id="" autocomplete="off">');
		
		$('body').prepend('<div class="slide-reveal-overlay" style="display: none; position: fixed; top: 0px; left: 0px; height: 100%; width: 100%; z-index: 1048; background-color: rgba(0, 0, 0, 0.5);"></div>');
		
		
		$('head').append('<link type="text/css" rel="stylesheet" href="http://personalizacionespre.gnoss.com/plantillas/hercules-responsive/theme/libraries/jqueryUI/jquery-ui.min.css">');
		
		iniciarDatepicker.init();
		
		this.crearModalAutor();
		this.crearModalDoc();
		
		
		
		this.crearModalEliminar();
		
		
		setInterval(function() {
			//Nuevo Doc
			if($('#publicaciones-panel-1 .btn-outline-grey').length>0 && !$('#publicaciones-panel-1 .btn-outline-grey').hasClass('btnActivo'))
			{
				$('#publicaciones-panel-1 .btn-outline-grey').addClass('btnActivo');
				$('#publicaciones-panel-1 .btn-outline-grey').on('click', function() {
					that.cargarModalDoc('');
				});
			}
			
			
			//Editar Doc
			if($('#publicaciones-panel-1 h2.resource-title a').length>0 )
			{
				$('#publicaciones-panel-1 h2.resource-title a').each(function( index ) {
					if(!$(this).hasClass('btnActivo'))
					{
						$(this).addClass('btnActivo');
						$(this).attr('data-toggle','modal');
						$(this).attr('data-target','#modal-anadir-datos-experiencia');
						
						$(this).on('click', function(event) {
							event.preventDefault()
							that.cargarModalDoc($(this).attr('data-id'));
						});
					}
				});		
				
			}
			
			//Guardar Doc
			if($('.contenedorEdicionDocumento a.btn-primary').length>0 && !$('.contenedorEdicionDocumento a.btn-primary').hasClass('btnActivo'))
			{
				$('.contenedorEdicionDocumento a.btn-primary').addClass('btnActivo');
				$('.contenedorEdicionDocumento a.btn-primary').on('click', function() {
					that.guardar('creacionDoc',$($('#actividad_cientifica .panel-group')[0]).attr('data-id'));
				});
			}
			
			//Nuevo autor
			if($('#creacionDoc .btn-outline-grey.add').length>0 && !$('#creacionDoc .btn-outline-grey.add').hasClass('btnActivo'))
			{
				$('#creacionDoc .btn-outline-grey.add').addClass('btnActivo');
				$('#creacionDoc .btn-outline-grey.add').on('click', function() {
					that.cargarModalAutor('','');
				});
			}
			
			//Editar persona			
			if($('.contenedorEdicionDocumento h2.resource-title a').length>0 )
			{
				$('.contenedorEdicionDocumento h2.resource-title a').each(function( index ) {
					if(!$(this).hasClass('btnActivo'))
					{
						$(this).addClass('btnActivo');
						$(this).attr('data-toggle','modal');
						$(this).attr('data-target','#modal-anadir-autor');
						
						$(this).on('click', function(event) {
							event.preventDefault()
							that.cargarModalAutor($(this).attr('data-id'),$(this).closest('.middle-wrap').find('.description-wrap p').text());
						});
					}
				});		
				
			}
			
			//Guardar Persona
			if($('#creacionAutor a.btn-primary').length>0 && !$('#creacionAutor a.btn-primary').hasClass('btnActivo'))
			{
				$('#creacionAutor a.btn-primary').addClass('btnActivo');
				$('#creacionAutor a.btn-primary').on('click', function() {
					that.guardar('creacionAutor');
				});
			}
			$( "input[propertyrdf='http://xmlns.com/foaf/0.1/name']" ).val($( "input[propertyrdf='http://xmlns.com/foaf/0.1/firstName']" ).val()+" "+ $( "input[propertyrdf='http://xmlns.com/foaf/0.1/lastName']" ).val());
						
			//Eliminar	
			$('#modal-eliminar a.btn-outline-primary').unbind().on('click', function(event) {
				event.preventDefault()
				console.log('Eliminar');				
				if($('#modal-eliminar').hasClass('documento'))
				{
					$.get(urlEdicion+'EliminarDocument?pID='+$('#modal-eliminar').attr('docid'), null, function (data) {
						$('#modal-eliminar .cerrar').click();
						console.log('recargar');
						$("a[data-id='"+$('#modal-eliminar').attr('docid')+"']").closest('article').remove();
						//RecargarListadoPublicaciones();
					});
				}else if($('#modal-eliminar').hasClass('persona'))
				{
					$('input[name="edicion-autor"]:checked').closest('article').remove();
					$('#modal-eliminar .cerrar').click();
				}
			});
			
			//Enganchar clase documento en eliminar
			$('.acciones-recurso-listado ul.no-list-style li a[data-toggle="modal"]').unbind().on('click', function(event) {				
				$('#modal-eliminar').removeClass('documento');
				$('#modal-eliminar').removeClass('persona');
				$('#modal-eliminar').addClass('documento');				
				$('#modal-eliminar').attr('docid',$(this).closest('article').find('h2.resource-title a').attr('data-id'));
			});
			
			//Enganchar clase persona en eliminar
			$('#collapse-autores .bteliminarpersona').unbind().on('click', function(event) {				
				$('#modal-eliminar').removeClass('documento');
				$('#modal-eliminar').removeClass('persona');
				$('#modal-eliminar').addClass('persona');
			});
			
				
			//No eliminar
			$('#modal-eliminar a.btn-primary').unbind().on('click', function(event) {
				event.preventDefault()
				$('#modal-eliminar .cerrar').click();
			});
								
			
			
		  
		}, 50);
    },
    crearModalDoc: function () {
		$('footer').after(`
		<div id="modal-anadir-datos-experiencia" class="modal modal-top modal-wide fade" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<p class="modal-title"><span class="material-icons">edit</span>Editar</p>
						<span class="material-icons cerrar" data-dismiss="modal" aria-label="Close">close</span>
					</div>
					<div class="modal-body contenedorEdicionDocumento">
						   

						
					</div>
				</div>
			</div>
		</div>`);
    },
    crearModalAutor: function () {
		$('footer').after(`
		<div id="modal-editar-autor" class="modal modal-top fade" tabindex="-1" role="dialog">
    
</div>
		<div id="modal-anadir-autor" class="modal modal-top fade" tabindex="-1" role="dialog">
			<div class="modal-dialog" role="document">
				<div class="modal-content modal-content-height">
					<div class="modal-header">
						<p class="modal-title"><span class="material-icons">person_add</span>Añadir autor</p>
						<span class="material-icons cerrar" data-dismiss="modal" aria-label="Close">close</span>
					</div>
					<div class="modal-body contenedorEdicionAutor">                
					</div>
				</div>
			</div>
		</div>`);
    },
	crearModalEliminar: function () {
		$('footer').after(`<div class="pmd-sidebar-overlay" data-rel="menuLateralUsuario"></div>
			<div id="modal-eliminar" class="modal modal-top fade modal-edicion" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <p class="modal-title"><span class="material-icons">delete</span>Eliminar</p>
                <span class="material-icons cerrar" data-dismiss="modal" aria-label="Close">close</span>
            </div>
            <div class="modal-body">
                <div class="formulario-edicion">
                    <div class="form-group">
                        <label class="control-label">¿Está seguro de que desea eliminar?</label>
                    </div>
                    <div class="form-actions">
                        <a href="" class="btn btn-primary">NO</a>
                        <a href="" class="btn btn-outline-primary">SI</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>`);
    },
    cargarModalDoc: function (pId) {
		$('.contenedorEdicionDocumento').empty();			
		MostrarUpdateProgress();
		$.get(urlEdicion+'GetDocument?pID='+pId, null, function (data) {			
			$('.contenedorEdicionDocumento').append(`
				<form id="creacionDoc" entityid="${data.id}" proptitle="http://w3id.org/roh/title" rdftype="http://purl.org/ontology/bibo/Document" ontology="document" class="formulario-edicion formulario-datos-experiencia"> 
					<div class="simple-collapse">
						<a class="collapse-toggle" data-toggle="collapse" href="#collapse-publicacion" role="button" aria-expanded="true" aria-controls="collapse-publicacion">
							Publicación
						</a>
						<div class="collapse show" id="collapse-publicacion">
							<div class="simple-collapse-content">
								<div class="custom-form-row">
									<div class="form-group full-group">
										<label class="control-label d-block">Título</label>
										<input propertyrdf="http://w3id.org/roh/title" placeholder="Introduce el titulo" value="${data.title}" type="text" name="" id="" class="form-control not-outline obligatorio">
									</div>
								</div>
								<div class="custom-form-row">
									<div class="form-group expand-2">
										<label class="control-label d-block">Nombre de la publicación</label>
										<input propertyrdf="http://vivoweb.org/ontology/core#hasPublicationVenue" placeholder="Introduce el nombre de la publicación" value="${data.nombrePublicacion}" type="text" name="" id="" class="form-control not-outline">
									</div>
									<div class="form-group">
										<label class="control-label d-block">Editorial</label>
										<input propertyrdf="http://purl.org/ontology/bibo/editor" placeholder="Introduce el editorial" value="${data.editorial}" type="text" name="" id="" class="form-control not-outline">
									</div>
								</div>
								<div class="custom-form-row">
									<div class="form-group">
										<label class="control-label d-block">Tipo de soporte</label>										${that.pintarSelect("http://w3id.org/roh/supportType",data.soporte,data.soporteList)}
									</div>
									<div class="form-group">
										<label class="control-label d-block">Tipo de publicación</label>
										${that.pintarSelect("http://purl.org/dc/elements/1.1/type",data.tipopublicacion,data.tipopublicacionList)}	
									</div>
									<div class="form-group form-group-date">
										<label class="control-label d-block">Fecha de la publicación</label>
										<input propertyrdf="http://purl.org/dc/terms/issued" title="Fecha de la publicación"  value="${data.fecha}" type="text" class="ac_input datepicker form-control not-outline" placeholder="Introduce la fecha de publicación" name="" id="" autocomplete="off">
										<span class="material-icons">today</span>
									</div>
								</div>
								<div class="custom-form-row">
									<div class="form-group full-group">
										<label class="control-label d-block">Descripción</label>										
										<textarea propertyrdf="http://purl.org/ontology/bibo/abstract" placeholder="Introduce la descripción" value="${data.description}" type="text" name="" id="" class="form-control not-outline"></textarea>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="simple-collapse">
						<a class="collapse-toggle collapsed" data-toggle="collapse" href="#collapse-volumen" role="button" aria-expanded="false" aria-controls="collapse-volumen">
							Volumen
						</a>
						<div class="collapse" id="collapse-volumen">
							<div class="simple-collapse-content">
								<div class="custom-form-row">
									<div class="form-group">
										<label class="control-label d-block">Volumen</label>
										<input propertyrdf="http://purl.org/ontology/bibo/volume" value="${data.volumen}" placeholder="Introduce el volumen" type="text" name="" id="" class="form-control not-outline">
									</div>
									<div class="form-group">
										<label class="control-label d-block">Número</label>
										<input propertyrdf="http://purl.org/ontology/bibo/issue" value="${data.numero}" placeholder="Introduce el número" type="text" name="" id="" class="form-control not-outline">
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="simple-collapse">
						<a class="collapse-toggle collapsed" data-toggle="collapse" href="#collapse-paginas" role="button" aria-expanded="false" aria-controls="collapse-paginas">
							Páginas
						</a>
						<div class="collapse" id="collapse-paginas">
							<div class="simple-collapse-content">
								<div class="custom-form-row">
									<div class="form-group">
										<label class="control-label d-block">Página inicial</label>
										<input propertyrdf="http://purl.org/ontology/bibo/pageStart" type="number" value="${data.paginaInicial}" placeholder="Introduce la página inicial" type="text" name="" id="" class="form-control not-outline">
									</div>
									<div class="form-group">
										<label class="control-label d-block">Páginal final</label>
										<input propertyrdf="http://purl.org/ontology/bibo/pageEnd" value="${data.paginaFinal}" placeholder="Introduce la página final" type="number" name="" id="" class="form-control not-outline">
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="simple-collapse">
						<a class="collapse-toggle collapsed" data-toggle="collapse" href="#collapse-autores" role="button" aria-expanded="false" aria-controls="collapse-autores">
							Autores
						</a>
						<div class="collapse" id="collapse-autores" style="">
							<div class="simple-collapse-content">
								<div class="acciones-listado acciones-listado-edicion">
					<div class="wrap">
						<ul class="no-list-style d-flex align-items-center">
							<li>
								<a class="btn btn-outline-grey">
									<span class="texto">Bajar</span>
									<span class="material-icons">arrow_drop_down</span>
								</a>
							</li>
							<li>
								<a class="btn btn-outline-grey">
									<span class="texto">Subir</span>
									<span class="material-icons">arrow_drop_up</span>
								</a>
							</li>
							<li>
								<a class="btn btn-outline-grey bteliminarpersona" data-toggle="modal" href="#modal-eliminar">
									<span class="texto">Eliminar</span>
									<span class="material-icons">delete</span>
								</a>
							</li>
						</ul>
					</div>
					<div class="wrap">
						<ul class="no-list-style d-flex align-items-center">
							<li>
								<a class="btn btn-outline-grey add" data-toggle="modal" href="#modal-anadir-autor">
									<span class="texto">Añadir</span>
									<span class="material-icons">person_add</span>
								</a>
							</li>
						</ul>
						<div id="buscador" class="buscador">
							<input type="text" id="txtBusquedaPrincipal" class="not-outline text txtBusqueda autocompletar personalizado ac_input" placeholder="Escribe algo..." autocomplete="off">
							<span class="botonSearch">
								<span class="material-icons">search</span>
							</span>
						</div>
					</div>
				</div>                <div class="resource-list listView resource-list-autores">
					<div class="resource-list-wrap">
					${that.pintarAutores(data.autores)}
					</div>
				</div>
								           </div>
						</div>
					</div>
				</form>
				<div class="form-actions">
                    <a class="btn btn-primary">GUARDAR</a>
                </div>`);
			iniciarSelects2.init();
			iniciarDatepicker.init();
			OcultarUpdateProgress();
		});
    },
    cargarModalAutor: function (pId,firma) {
		$('.contenedorEdicionAutor').empty();
		MostrarUpdateProgress();		
		$.get(urlEdicion+'GetAutor?pID='+pId, null, function (data) {			
			$('.contenedorEdicionAutor').append(`
				<form id="creacionAutor" entityid="${data.id}" proptitle="http://xmlns.com/foaf/0.1/name" rdftype="http://xmlns.com/foaf/0.1/Person" ontology="person" class="formulario-edicion formulario-autor" style="">
                    <div class="custom-form-row">
                        <div class="form-group expand-2">
                            <label class="control-label d-block">Código ORCID</label>
                            <input propertyrdf="http://w3id.org/roh/ORCID" value="${data.ORCID}" placeholder="Introduce el código ORCID" type="text" name="" id="" class="form-control not-outline">
                        </div>
                    </div>
					<div class="custom-form-row">
                        <div class="form-group full-group">
                            <label class="control-label d-block">Firma</label>
                            <input id="firmaPersona" value="${firma}" placeholder="Introduce la firma" type="text" name="" id="" class="form-control not-outline obligatorio">
                        </div>
                    </div>
                    <div class="custom-form-row">
                        <div class="form-group full-group">
                            <label class="control-label d-block">Nombre</label>
                            <input id="nombrePersona" propertyrdf="http://xmlns.com/foaf/0.1/firstName" value="${data.Nombre}" placeholder="Introduce el nombre" type="text" name="" id="" class="form-control not-outline obligatorio">
                        </div>
                    </div>
                    <div class="custom-form-row">
                        <div class="form-group full-group">
                            <label class="control-label d-block">Apellidos</label>
                            <input id="apellidosPersona" propertyrdf="http://xmlns.com/foaf/0.1/lastName" value="${data.Apellidos}" placeholder="Introduce los apellidos" type="text" name="" id="" class="form-control not-outline obligatorio">
                        </div>
                    </div>	
					<div class="custom-form-row oculto">
                        <div class="form-group full-group">
                            <label class="control-label d-block">Nombre completo</label>
                            <input propertyrdf="http://xmlns.com/foaf/0.1/name" placeholder="Introduce el nombre" type="text" name="" id="" class="form-control not-outline">
                        </div>
                    </div>					
                    <div class="form-actions">
                        <a class="btn btn-primary uppercase" data-dismiss="modal">Aceptar</a>
                    </div>
                </form>	`);
			iniciarSelects2.init();
			iniciarDatepicker.init();
			OcultarUpdateProgress();
		});
    },
    pintarSelect: function (pPropertyRDF,pId,pItems) {
		var selector='<select propertyrdf="'+pPropertyRDF+'" id="" name="" class="js-select2" data-select-search="true">'+
			'<option value=""></option>';
			for (var propiedad in pItems){
				if(propiedad==pId)
				{
					selector+='<option selected value="'+propiedad+'">'+pItems[propiedad]+'</option>';
				}else
				{
					selector+='<option value="'+propiedad+'">'+pItems[propiedad]+'</option>';
				}
			}
			selector+="</select>";
		return selector;
	},pintarAutores: function (pAutores) {
		var strAutor="";
		var checked="checked";
				
		for (var autor in pAutores){
			strAutor+=this.aniadirPersona(pAutores[autor],checked);
			checked="";
		}
		return strAutor;
	},
    aniadirPersona: function (persona,checked) {
		return `<article class="resource">
				<input propertyrdf="http://purl.org/ontology/bibo/authorList@@@http://purl.obolibrary.org/obo/BFO_0000023|http://www.w3.org/1999/02/22-rdf-syntax-ns#member" value="${persona.idBFO}@@@${persona.id}" type="hidden">
				<input propertyrdf="http://purl.org/ontology/bibo/authorList@@@http://purl.obolibrary.org/obo/BFO_0000023|http://www.w3.org/1999/02/22-rdf-syntax-ns#comment" value="${persona.idBFO}@@@${persona.orden}" type="hidden">
				<input propertyrdf="http://purl.org/ontology/bibo/authorList@@@http://purl.obolibrary.org/obo/BFO_0000023|http://xmlns.com/foaf/0.1/nick" value="${persona.idBFO}@@@${persona.firma}" type="hidden">
				
				
				<div class="custom-control themed little custom-radio">
					<input type="radio" id="edicion-autor-${persona.id}" name="edicion-autor" class="custom-control-input" ${checked}>
					<label class="custom-control-label" for="edicion-autor-${persona.id}"></label>
				</div>
				<div class="wrap">
					<div class="middle-wrap">
						<div class="title-wrap">
							<h2 class="resource-title">
								<a data-id="${persona.id}" href="#">${persona.Nombre} ${persona.Apellidos}</a>
							</h2>
						</div>
						<div class="content-wrap">
							<div class="description-wrap">
								<div class="desc">
									<p>${persona.firma}</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</article>`;
	},
    guardar: function (pFormulario,aux) {
		var that=this;
		var entidad={};
		entidad.id=$('#'+pFormulario).attr('entityid');
		entidad.propTitle=$('#'+pFormulario).attr('proptitle');
		entidad.ontology=$('#'+pFormulario).attr('ontology');
		entidad.rdfType=$('#'+pFormulario).attr('rdftype');
		entidad.aux=aux;
		entidad.properties=[];
		
		var camposObligatorios=[];
		$('#'+pFormulario).find('input, select, textarea').each(function( index ) {
		  if($(this).attr('propertyrdf')!=null)
		  {
			  if($(this).hasClass('obligatorio') && ($(this).val()==null || $(this).val()==''))
			  {
				 camposObligatorios.push( $(this).closest('.form-group').find('.control-label').text());
			  }
			  var property=$(this).attr('propertyrdf');
			  var fecha=false;
			  if(property=="http://purl.org/dc/terms/issued")
			  {
				  fecha=true;
			  }
			  var prop=null;
			  for (var indice in entidad.properties){
				  if(entidad.properties[indice].prop==property)
				  {
					  prop=entidad.properties[indice];
				  }
			  };
			  if(prop==null)
			  {
				  prop={};
				  prop.prop=property;
				  prop.values=[];
			  }
			  if(fecha && $(this).val()!=null && $(this).val()!='')
			  {
				  var fechaAux=$(this).val().substring(6,10)+$(this).val().substring(3,5)+$(this).val().substring(0,2)+"000000";
				  prop.values.push(fechaAux);
			  }else
			  {
				prop.values.push($(this).val());
			  }
			  entidad.properties.push(prop);
		  }
		});
		$('.modal .form-actions .ko').remove();
		if(camposObligatorios.length>0)		
		{
			var error="";
			for (var indice in camposObligatorios){
				  
					  error+='<p>El campo '+camposObligatorios[indice]+' es obligatorio</p>';
				  
			  };
			$('#'+pFormulario).closest('.modal').find(' .form-actions').append('<div class="ko" style="display:block"><p>'+error+'</p></div>');
				
		}else
		{		
			MostrarUpdateProgress();
			$.post(urlEdicion+'updateEntity',entidad, function( data ) {
				if(pFormulario=='creacionAutor')
				{
					var firma=$('#firmaPersona').val();
					var Nombre=$('#nombrePersona').val();
					var Apellidos=$('#apellidosPersona').val();
					if(entidad.id=='')
					{
						//nuevo
						var persona={};
						persona.idBFO=RandomGuid();
						persona.id=data.id;
						persona.orden=1;
						persona.firma=firma;
						persona.Nombre=Nombre;
						persona.Apellidos=Apellidos;
						var checked="";
						$( "input[propertyrdf='http://purl.org/ontology/bibo/authorList@@@http://purl.obolibrary.org/obo/BFO_0000023|http://www.w3.org/1999/02/22-rdf-syntax-ns#comment']" ).each(function( index ) {
							var order=parseInt($(this).val().substring($(this).val().indexOf('@@@')+3,$(this).val().length));
							if(persona.orden<=order)
							{
								persona.orden=order+1;
							}
							
						});
						if(persona.orden==1)
						{
							checked="checked";
						}
						$('.resource-list-autores .resource-list-wrap').append( that.aniadirPersona(persona,checked));
					}else
					{
						var articlePersona=$("a[data-id='"+data.id+"']").closest('article');
						
						var antiguoValorNick=articlePersona.find("input[propertyrdf='http://purl.org/ontology/bibo/authorList@@@http://purl.obolibrary.org/obo/BFO_0000023|http://xmlns.com/foaf/0.1/nick']").val();
						articlePersona.find("input[propertyrdf='http://purl.org/ontology/bibo/authorList@@@http://purl.obolibrary.org/obo/BFO_0000023|http://xmlns.com/foaf/0.1/nick']").html(antiguoValorNick.substring(0,antiguoValorNick.lastIndexOf("@@@"))+'@@@'+firma);
						
						$("a[data-id='"+data.id+"']").html(Nombre+' '+Apellidos);
						
						articlePersona.find('.description-wrap .desc p').html(firma);
					}
				}else{
					console.log('recargar');	
					RecargarListadoPublicaciones();					
				}
				if(data.ok)
				{
					$('#'+ $('#'+pFormulario).closest('.modal').attr('id')).modal('hide');
					
				}else
				{
					alert("Error: "+data.error);
				}
				OcultarUpdateProgress();
			});
		}
    }
}

function RecargarListadoPublicaciones()
{
	document.getElementById('changeelementchild').innerHTML = "<p>"+RandomGuid()+"</p>"
}

function RandomGuid()
{
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}
